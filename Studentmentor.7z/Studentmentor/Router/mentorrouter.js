const express = require('express');
const mentor=require("../moduletask/mentor")
        const router = express.Router()
//get
router.get('/mentordetails',async(req,res)=>{
     
    try{
            const getallusers=await mentor.find({})
            res.send(getallusers)

    }
   catch(e){res.send({message:"user not found"})

    }   
 })
//add
 router.post('/mentorpost',async(req,res)=>{
        const {name,email,course} = req.body;
        const addMentor = new mentor({
            "name" : name,
            "email" : email,
            "course" : course
        })
     
        try{
                const getallusers=await addMentor.save()
                res.send(getallusers)
    
        }
       catch(e){res.send({message:"user not found"})
    
        }   
     })
     //get mentor based on id

     router.get('/mentorpost/:id',async(req,res)=>{
        const {id} = req.params;
        
     
        try{
                const getallusers=await mentor.findById({_id:id})
                res.send(getallusers)
    
        }
       catch(e){res.send({message:"user not found"})
    
        }   
     })
 module.exports=router