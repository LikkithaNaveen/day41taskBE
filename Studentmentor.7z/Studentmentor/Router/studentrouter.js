const express = require('express');
const student=require('../moduletask/student')
const router = express.Router()
//add
// router.get('/getstudent',async(req,res)=>{
     
//         try{
//                 const getallusers=await student.find({})
//                 res.send(getallusers)
    
//         }
//        catch(e){res.send({message:"user not found"})
    
//         }   
//      })
router.post('/addstudent',async(req,res)=>{
//     const {name,batch,mentor} = req.body;
//     const addstudent = new student({
//         "name" : name,
//         "batch" : batch,
//         "mentor" : mentor
//     })
//     console.log("1222")

  const addstudent=new student(req.body)
 
    try{
            const getallusers=await addstudent.save()
            res.send(getallusers)
s
    }
   catch(e){res.send({message:"user not found"})

    }   
 })
/*  List of students with no mentors */

router.get('/no-mentors',async (req,res) => {
    const students = await student.find({mentor:undefined})
    res.send(students);
})

/* Assign or change Mentor for Student -- select one student and assign one mentor */

router.patch('/assign-mentor/:id',async (req,res) => {
    const {id} = req.params;
    const {mentor} = req.body;
    try{
        const student = await student.findById(id);
        student.mentor = mentor;
        await student.save();
        res.send(student);
    }catch(err){
       res.send({message:"user not found"})
    }
})

/* select one mentor and add to multiple students */

router.patch('/assign-mentor-students', async (req,res) => {
    const {mentor,stud_list} = req.body;
    console.log(stud_list)
    try{
        stud_list.map( async (stud_id) => {
            const student = await student.findById(stud_id)
            student.mentor = mentor;
            await student.save();
        })
        res.send("Updated Successfully");  
    }catch(err){
        res.send({message:"user not found"})
    }
})

/* show all students for a particular mentor */

router.get('/mentor-students/:id',async (req,res) => {
    const {id} = req.params;
    try{
        const students = await student.find({mentor : id});
        res.send(students);
    }catch(err){
         res.send({message:"user not found"})
    }
})

module.exports = studentrouter;