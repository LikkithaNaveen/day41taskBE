require("./DB/connection")
const mentor=require('./Router/mentorrouter')
const student=require('./Router/studentrouter')
const express = require('express')
const app = express()


const port = 8000;




app.use(express.json())

app.use(mentor)

//app.use(studentmentor)


 //
app.listen(port,()=>{
    console.log(`port started:${port}`)
})