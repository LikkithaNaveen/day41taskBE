const mongoose = require("mongoose");
const validator = require('validator');


// mongoose.connect("mongodb://localhost:27017/Stu",{
//     useNewUrlParser:true
// })


// mongoose.connect("mongodb://localhost:27017/mangoose-task",{
//     useNewUrlParser:true
// })

//const mentorscheme= new mongoose.Schema(c
const mentorscheme= new mongoose.Schema(
    
    {
        name:{
            type:String,
            required:true,
            lowercase:true
        },
        email:{
            type:String,
           lowercase:true,
            required:true,
        },
        course:{
            type:String,
            required:true,
            lowercase:true
        },
    }

)
// const userdate=new user({ 
//     name:"likkitha",
//     email:"add@gmail.com",
//     course:"fullstack"
  
// })
//save to db

//console.log(userdate)

//userdate.save()

const mentor=mongoose.model('Mentors', mentorscheme);
module.exports=mentor

