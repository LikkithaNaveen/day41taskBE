// const mongoose = require("mongoose");
// const validator = require('validator');



// // mongoose.connect("mongodb://localhost:27017/mangoose-task",{
// //     useNewUrlParser:true
// // })
// const userstudent=mongoose.model('Students',

// //const studentscheme= new mongoose.Schema(
//     {
//         name:{
//             type:String,
//             required:true,
//             lowercase:true
//         },
//         batch:{
//             type:String,
//            lowercase:true,
//             required:true
//         },
//         mentor:{
//             type :String,//=>covert to string
//             default : undefined,
//             required:true
//            // ref : 'mentor'
//         }
//     }

// )

// const userdate=new userstudent({ 
//     name:"susmi",
//     batch:"add@gmail.com",
//     mentor:"fullstack"
  
// })
// /////save to db

// console.log(userdate)

// userdate.save()


// // const studentmentor=mongoose.model('Students', studentscheme);
// // module.exports=studentmentor

const mongoose = require("mongoose");
const validator = require('validator');

mongoose.connect("mongodb://localhost:27017/mangoose-task",{
    useNewUrlParser:true
})
//define the model
// const user=mongoose.model('task',{
//     description:{
//         type:String
//     },
//     status:{
//         type:Number
//     }

     
// })

// const userdate=new user({
//     description:"updated work details",
//     status:true
// })
// //save to db

// userdate.save()

 // "start": "node Nodeday3task/await/index.js",
    // "dev": "nodemon Nodeday3task/await/index.js",

const user=mongoose.model('studentss',{
    name:{
        type:String,
        required:true,
        lowercase:true
    },
    age:{
        type:Number,
        default:15,
        validate(value){
            if(value<15)
            throw new Error("age is more than 15")
    }},
    email:{
        type:String,
       lowercase:true,
        required:true,
        validate(value){
            if(!validator.isEmail(value))
            throw new Error("value is more thax max/min length")
            }
    },
    password:{
        type:String,
       lowercase:true,
        required:true,
        validate(value){
            if(value.includes("password"))
            throw new Error("password updated")
            }
    }
})
const userdate=new user({ 
    name:"likkitha",
    age:25,
    email:"add@gmail.com",
    password:"likki124"
  
})
//save to db

userdate.save()
//userdate.save().then()=>console.log(userdate).catch(err=>(console.log(err)))